import logging
import os

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
)
logger = logging.getLogger(__name__)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message:
        await update.message.reply_text(
            "مرحبًا بك في بوت SMC التجريبي!\n\n"
            "البوت متصل ويعمل. تحليل السوق ومراقبة الصفقات لم يُفعّلا بعد.\n"
            "استخدم /help لعرض الأوامر."
        )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message:
        await update.message.reply_text(
            "الأوامر المتاحة:\n"
            "/start — بدء الاستخدام\n"
            "/help — عرض المساعدة\n"
            "/status — حالة البوت"
        )


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message:
        await update.message.reply_text(
            "الحالة: يعمل ✅\n"
            "وضع التداول: تجريبي فقط\n"
            "تحليل SMC: لم يُفعّل بعد"
        )


def main() -> None:
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        raise RuntimeError(
            "متغير TELEGRAM_BOT_TOKEN غير مضبوط. أضف رمز البوت كمتغير بيئة؛ "
            "لا تضعه داخل الكود أو GitHub."
        )

    application = Application.builder().token(token).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("status", status))

    logger.info("Starting Telegram bot polling")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
